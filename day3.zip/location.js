var request= require('request');

var appurl= 'http://ipinfo.io';

module.exports= function(callback){

    request({
        url:appurl,
        json:true,

    },function(error,response,body){
        if(error){
            callback();
        }
        else{
            callback(body)
        }
    })
}